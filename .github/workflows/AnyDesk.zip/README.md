## Disala-Anydesk-Windows-10-RDP-🇱🇰 

# Read This Before Rushing To Actions Tab 💀

* Note : make suer to install [AnyDesk](https://anydesk.com/en/downloads/windows) in your device.
* Note : i'm not responsible for suspended accounts
* Note : 30 miniute github timelimit bypassed now its 6 hours
* Note : Lower timelimit if u want to save ur github account (to 4 hours)

### Windows 10 Least

VM features:
- 2-core vCPU
- 7 GB RAM
- 100 GB Disk **(Excluded System Used)**
* We Have Some Cool Features That Other Scripts Dosen't Have
  - Automatically Telegram Installed
  - Automatically Winrar Installed
  - Automatically Open Bullet Installed
  - Automatically VM Quick Config Installed and Configuerd
  - Small Taskbar
  - Removed Stupid/Unrated Softwares
  - YT Watchtime Hack Cheat
  - Automatically Qbit Installed 
  - Ect ...

## Deploy and Run
<details>
    <summary>Windows 10 RDP Install and Run</summary>
<br>

* Note: Don't Make Github RDPs with personal account, [Github Unlimited Accounts Method](https://youtu.be/b-hDeGpPLhY).
  
* Go to [**Here**](https://t.me/TheDisala4U/493) and download the **Windows - Anydesk RDP.yml**. (workflows file is on telegram channel, sub to me if u want)
    
* Create new github repo , click **create new file** and copy this text **.github/workflows/test** also type test in empty box and click **committed changes** after that **upload Windows - Anydesk RDP.yml in there**.
    
* Now go to **Actions** Tab and select one of system workflow.

* Click **Run Workflow** button on the left of **This workflow has a workflow_dispatch event trigger** line.

* Wait until a few minutes.

* Copy the **Anydesk ID** and Open AnyDesk.exe and paste your ID in there and press enter then Give Password As **disalardp**

* Agin Press Enter. **(Note: Don't Close Any Ongoing Tabs In Taskbar)

* Enjoy!

</details>

# You need proof then click action tab...

# [Watch Tutorial If You Dosen't Understand This.](https://youtu.be/xHr0cPjSRFg)

### Brought To You By Disala 💀 , Its Functional 😗.
### You Can See ID , Pass And Cool Ascki Art 
